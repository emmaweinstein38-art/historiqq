# HISTORIQ — a history date guessing game

This is a real, fully playable static website. It has a homepage, topic selection, year-range filtering, multiple rounds, score calculations, historical explanations and a results screen. The starter version runs entirely in your browser and doesn't need a database, sign-in or paid services.

## Play on your computer

Open `index.html` in Chrome, Safari or another browser. Keep `index.html`, `style.css`, `script.js` and `events.js` in the same folder. The Google Fonts link is optional; the game works offline with fallback fonts.

## Publish on GitHub Pages (free)

1. Create a GitHub account at https://github.com/ if you don't have one.
2. At https://github.com/new create a **Public** repository, e.g. `historiq`, and click **Create repository**.
3. In that repository, choose **Add file → Upload files**. Upload the **contents** of this folder: `index.html`, `style.css`, `script.js`, `events.js`, `.nojekyll`, and optionally `README.md`. Important: `index.html` must be at the repository root, not inside a subfolder or the ZIP file.
4. Click **Commit changes**.
5. Go to **Settings → Pages**. Under **Build and deployment**, set **Source: Deploy from a branch**, **Branch: main**, **Folder: /(root)**, and click **Save**.
6. Check the **Pages** settings for your published URL once deployment has completed. It will usually look like `https://YOUR-USERNAME.github.io/historiq/`.
7. Share that link. People can play immediately without searching Google.

## Help Google discover it

After it is live, open https://search.google.com/search-console/about, add and verify your website address, and use URL inspection to request indexing. Indexing can take time and is not guaranteed. A custom domain can be added later if you wish.

## Customize

- Name, homepage text and layout: `index.html`
- Colors, typography, and mobile design: `style.css`
- Scoring, game rules and selection: `script.js`
- Historical questions: `events.js`

To add a date, insert a new entry in `RAW_EVENTS` with the format:

`['1945-05-08','Victory in Europe Day','War','World War II','Description of the event.'],`

Use `YYYY-MM-DD` and make sure the event date is verified. The site deliberately limits selectable years to 1700–2026 because the starter list covers that period; some topic/period combinations have few or no events. The game tells the player how many eligible events exist before play. Dates are expressed in the Gregorian calendar (with dates earlier than Gregorian adoption in some countries conventionally represented as Gregorian where applicable).

**No accounts or leaderboard yet:** This is version one, intended to be straightforward to publish. Adding accounts, shared scores, user-generated event lists or automatically generating events would require additional services and content verification.
